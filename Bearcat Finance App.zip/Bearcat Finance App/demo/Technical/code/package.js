
{
  "name": "bearcatbank",
  "version": "1.0.0",
  "description": "a bank to send transactions to our bearcat finance app",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "",
  "license": "ISC",
  "dependencies": {
    "axios": "^1.7.9",
    "bcrypt": "^5.1.1",
    "body-parser": "^1.20.3",
    "cookie-parser": "^1.4.7",
    "cors": "^2.8.5",
    "dotenv": "^16.4.7",
    "express": "^4.21.2",
    "express-jwt": "^8.5.1",
    "express-validator": "^7.2.1",
    "formidable": "^3.5.2",
    "git": "^0.1.5",
    "jsonwebtoken": "^9.0.2",
    "loadash": "^1.0.0",
    "mongoose": "^8.9.5",
    "mysql2": "^3.12.0",
    "nodemailer": "^6.9.16",
    "path": "^0.12.7",
    "sequelize": "^6.37.5",
    "uuid": "^11.0.5"
  }
}
